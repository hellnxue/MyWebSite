$(document).ready(function(){
	$(".box_height_window").height($(window).height());
	$(".box_height_view").height($(window).height()-$(".wap-view-top").height()-9);
	
	
	$(".tool-line").mouseover(function(){
		$(this).hide();
		$(".tool-menu").show();
	});
	
	$(".tool-menu").mouseleave(function(){
		$(document).mouseup(function(event){ 
		  if($(event.target).parents(".tool-menu").length==0){
			$(".tool-menu").hide();
			$(".tool-line").show();
		  } 
		});
	});
	
	$(".tool_flag").mouseover(function(){
		$(this).hide();
		$(".tool_block").show();
	});
	
	
	$(".tool_close").click(function() {
		$(".tool_block").hide();
		$(".tool_flag").show();
	});
	
	
	$(".box-pop-toolbut").click(function() {
		$(".box-pop-toolview").show();
		$(".nano").nanoScroller({alwaysVisible: true});
	});
	$(".box-closepop").click(function() {
		$(".tool-menu").hide();
		$(".box-pop-toolview").hide();
		$(".tool-line").show();
	});
	
	
	$(".box-pop-indexbut").click(function() {
		$(".box-pop-toolview").hide();
	});
	
	
	
	$(".tool-menu-list li").click(function() {
		$(this).addClass("cur").siblings().removeClass("cur");
	});
	/*$(".wrapper_menu_list li").click(function() {
		$(this).addClass("cur").siblings().removeClass("cur");
	});*/
	
	$(".wrapper_menu_list li a").each(function (e) {
		$(this).click(function () {
			  $(this).parents("li").addClass("cur").siblings().removeClass("cur");
		      $(".nano-content").animate({ scrollTop: $(".wrapper_view_one").get(e).offsetTop}, 1000);
		})
	});
	
	$(".wrapper_view_content").scroll(function () {
		$(".wrapper_menu_list li a").each(function (e) {
			if($(".wrapper_view_content").scrollTop() >= $(".wrapper_view_one").get(e).offsetTop && $(".wrapper_view_content").scrollTop() < $(".wrapper_view_one").get(e+1).offsetTop){
				$(".wrapper_menu_list li").eq(e).addClass("cur").siblings().removeClass("cur");
			}
		});
		
	});
	 
	
});

$(window).resize(function () { 
	$(".box_height_window").height($(window).height());
	$(".box_height_view").height($(window).height()-$(".header").height());
});

