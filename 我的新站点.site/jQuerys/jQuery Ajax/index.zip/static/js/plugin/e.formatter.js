function booleanF(value,rowData,rowIndex,clm,d){
	if(value==1 || value=="1" ||value==true || value=="true" ){
		return "是";
	}
	if(value==0 || value=="0" || value==false || value=="false" ){
		return "否";
	}
}

